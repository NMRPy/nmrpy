# NMRPy

NMRPy is a Python module for the processing and analysis of NMR spectra. The
functionality of NMRPy is structured to make the analysis of arrayed NMR
spectra more intuitive.

Read the docs at http://nmrpy.readthedocs.io/
